
# Checkpoint Desktop (JavaFX)

## Run
Make sure the backend is running on http://localhost:8080

Then:
```bash
mvn -q -DskipTests javafx:run
```

Edit `DesktopApp` to change `backendUrl`, `userId`, `projectId`.
