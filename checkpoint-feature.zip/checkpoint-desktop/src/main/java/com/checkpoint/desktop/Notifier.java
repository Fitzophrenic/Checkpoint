
package com.checkpoint.desktop;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Popup;
import javafx.stage.Stage;

public class Notifier {
    private final Stage stage;
    public Notifier(Stage stage) { this.stage = stage; }

    public void show(String title, String message) {
        Platform.runLater(() -> {
            Popup popup = new Popup();
            Label lbl = new Label(title + "\n" + message);
            StackPane box = new StackPane(lbl);
            box.setPadding(new Insets(12));
            box.setStyle("-fx-background-color: rgba(30,30,30,0.92); -fx-text-fill: white; "
                    + "-fx-background-radius: 12; -fx-font-size: 13px;");
            popup.getContent().add(box);
            double x = stage.getX() + stage.getWidth() - 320;
            double y = stage.getY() + stage.getHeight() - 120;
            popup.show(stage, x, y);
            new Thread(() -> {
                try { Thread.sleep(4000); } catch (InterruptedException ignored) {}
                Platform.runLater(popup::hide);
            }).start();
        });
    }
}
