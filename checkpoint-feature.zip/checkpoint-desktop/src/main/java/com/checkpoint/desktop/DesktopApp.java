
package com.checkpoint.desktop;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class DesktopApp extends Application {

    private NotificationPoller poller;

    @Override
    public void start(Stage stage) {
        stage.setTitle("Checkpoint Desktop (Notifications Demo)");
        BorderPane root = new BorderPane();
        root.setTop(new Label("Polling backend for due notifications..."));
        Button quit = new Button("Quit");
        quit.setOnAction(e -> {
            if (poller != null) poller.stop();
            stage.close();
        });
        root.setBottom(quit);
        Scene scene = new Scene(root, 480, 220);
        stage.setScene(scene);
        stage.show();

        Notifier notifier = new Notifier(stage);

        // Configure your backend URL and IDs here:
        String backendUrl = "http://localhost:8080";
        String userId = "user123";
        String projectId = "projA";

        poller = new NotificationPoller(backendUrl, userId, projectId, notifier);
        poller.start();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
