
package com.checkpoint.desktop;

import javafx.application.Platform;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;

public class NotificationPoller {
    private final String backendUrl;
    private final String userId;
    private final String projectId;
    private final Notifier notifier;
    private Timer timer;

    public NotificationPoller(String backendUrl, String userId, String projectId, Notifier notifier) {
        this.backendUrl = backendUrl.endsWith("/") ? backendUrl.substring(0, backendUrl.length() - 1) : backendUrl;
        this.userId = userId;
        this.projectId = projectId;
        this.notifier = notifier;
    }

    public void start() {
        timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override public void run() { checkForDue(); }
        }, 0, 20_000);
    }

    public void stop() {
        if (timer != null) timer.cancel();
    }

    private void checkForDue() {
        try {
            String urlStr = backendUrl + "/api/notifications/due?userId=" + encode(userId)
                    + (projectId != null ? "&projectId=" + encode(projectId) : "");
            HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(4000);
            conn.setReadTimeout(4000);

            if (conn.getResponseCode() != 200) return;

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                JSONObject json = new JSONObject(sb.toString());
                JSONArray items = json.getJSONArray("items");
                for (int i = 0; i < items.length(); i++) {
                    JSONObject n = items.getJSONObject(i);
                    String title = n.getString("title");
                    String msg = n.getString("message");
                    long id = n.getLong("id");
                    Platform.runLater(() -> notifier.show(title, msg));
                    markSeen(id);
                }
            } finally {
                conn.disconnect();
            }
        } catch (Exception ignored) { }
    }

    private void markSeen(long id) {
        try {
            String urlStr = backendUrl + "/api/notifications/mark-seen?id=" + id + "&seen=true";
            HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(3000);
            conn.getResponseCode();
            conn.disconnect();
        } catch (Exception ignored) { }
    }

    private static String encode(String s) {
        try { return java.net.URLEncoder.encode(s, java.nio.charset.StandardCharsets.UTF_8); }
        catch (Exception e) { return s; }
    }
}
