
# Checkpoint Backend (Spring Boot + SQLite)

## Run
```bash
mvn spring-boot:run
```

Server: http://localhost:8080

## Endpoints
- `GET /health` -> `{"status":"up"}`
- `POST /api/notifications/create` JSON:
  ```json
  { "userId":"user123", "projectId":"projA", "title":"Playtest", "message":"Starts soon", "fireAt": 1733260800000 }
  ```
- `GET /api/notifications/due?userId=user123&projectId=projA`
- `POST /api/notifications/mark-seen?id=1&seen=true`
- `GET /api/notifications`
- `DELETE /api/notifications/{id}`
