
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT,
  project_id TEXT,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  fire_at INTEGER NOT NULL,
  seen INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_notifications_fire_at_seen
  ON notifications(fire_at, seen);
