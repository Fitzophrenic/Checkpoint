
package com.checkpoint.backend;

import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Service
public class NotificationService {
    private final SQLRequest sql;

    public NotificationService(SQLRequest sql) {
        this.sql = sql;
    }

    public long create(String userId, String projectId, String title, String message, long fireAt) {
        long clamped = Math.max(fireAt, Instant.now().toEpochMilli() + 3000L);
        return sql.createNotification(userId, projectId, title, message, clamped);
    }

    public List<Map<String, Object>> due(String userId, String projectId) {
        return sql.getDueNotifications(userId, projectId, Instant.now().toEpochMilli());
    }

    public void markSeen(long id, boolean seen) {
        sql.markNotificationSeen(id, seen);
    }

    public List<Map<String, Object>> list(String userId, String projectId, Boolean seen, int limit, int offset) {
        return sql.listNotifications(userId, projectId, seen, limit, offset);
    }

    public void delete(long id) {
        sql.deleteNotification(id);
    }
}
