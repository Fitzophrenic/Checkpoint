
package com.checkpoint.backend;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final NotificationService svc;

    public NotificationController(NotificationService svc) {
        this.svc = svc;
    }

    @PostMapping("/create")
    public ResponseEntity<?> create(@RequestBody CreateReq req) {
        long id = svc.create(req.userId, req.projectId, req.title, req.message, req.fireAt);
        return ResponseEntity.ok(Map.of("status", "ok", "id", id));
    }

    @GetMapping("/due")
    public ResponseEntity<?> due(@RequestParam String userId,
                                 @RequestParam(required = false) String projectId) {
        List<Map<String, Object>> items = svc.due(userId, projectId);
        return ResponseEntity.ok(Map.of("status", "ok", "items", items));
    }

    @PostMapping("/mark-seen")
    public ResponseEntity<?> markSeen(@RequestParam long id,
                                      @RequestParam(defaultValue = "true") boolean seen) {
        svc.markSeen(id, seen);
        return ResponseEntity.ok(Map.of("status", "ok"));
    }

    @GetMapping
    public ResponseEntity<?> list(@RequestParam(required = false) String userId,
                                  @RequestParam(required = false) String projectId,
                                  @RequestParam(required = false) Boolean seen,
                                  @RequestParam(defaultValue = "100") int limit,
                                  @RequestParam(defaultValue = "0") int offset) {
        return ResponseEntity.ok(Map.of("status", "ok", "items", svc.list(userId, projectId, seen, limit, offset)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable long id) {
        svc.delete(id);
        return ResponseEntity.ok(Map.of("status", "ok"));
    }

    public static class CreateReq {
        public String userId;
        public String projectId;
        public String title;
        public String message;
        public long fireAt;
    }
}
