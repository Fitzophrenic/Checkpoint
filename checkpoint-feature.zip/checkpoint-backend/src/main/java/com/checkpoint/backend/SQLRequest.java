
package com.checkpoint.backend;

import org.springframework.stereotype.Component;

import java.sql.*;
import java.util.*;

@Component
public class SQLRequest {

    private static final String DB_URL = "jdbc:sqlite:checkpoint.db";

    // --- Notification Methods ---

    public long createNotification(String userId, String projectId, String title, String message, long fireAt) {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO notifications (user_id, project_id, title, message, fire_at, seen) VALUES (?,?,?,?,?,0)",
                     Statement.RETURN_GENERATED_KEYS
             )) {
            ps.setString(1, userId);
            ps.setString(2, projectId);
            ps.setString(3, title);
            ps.setString(4, message);
            ps.setLong(5, fireAt);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getLong(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException("createNotification failed: " + e.getMessage(), e);
        }
        return -1;
    }

    public List<Map<String, Object>> getDueNotifications(String userId, String projectId, long nowMillis) {
        List<Map<String, Object>> list = new ArrayList<>();
        String sql = "SELECT * FROM notifications WHERE seen=0 AND fire_at<=?" +
                (userId != null ? " AND user_id=?" : "") +
                (projectId != null ? " AND project_id=?" : "") +
                " ORDER BY fire_at ASC";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            int idx = 1;
            ps.setLong(idx++, nowMillis);
            if (userId != null) ps.setString(idx++, userId);
            if (projectId != null) ps.setString(idx++, projectId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> map = new LinkedHashMap<>();
                    map.put("id", rs.getLong("id"));
                    map.put("userId", rs.getString("user_id"));
                    map.put("projectId", rs.getString("project_id"));
                    map.put("title", rs.getString("title"));
                    map.put("message", rs.getString("message"));
                    map.put("fireAt", rs.getLong("fire_at"));
                    map.put("seen", rs.getInt("seen") == 1);
                    list.add(map);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("getDueNotifications failed: " + e.getMessage(), e);
        }
        return list;
    }

    public int markNotificationSeen(long id, boolean seen) {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement ps = conn.prepareStatement("UPDATE notifications SET seen=? WHERE id=?")) {
            ps.setInt(1, seen ? 1 : 0);
            ps.setLong(2, id);
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("markNotificationSeen failed: " + e.getMessage(), e);
        }
    }

    public List<Map<String, Object>> listNotifications(String userId, String projectId, Boolean seen, int limit, int offset) {
        List<Map<String, Object>> items = new ArrayList<>();
        StringBuilder sb = new StringBuilder("SELECT * FROM notifications WHERE 1=1");
        List<Object> args = new ArrayList<>();
        if (userId != null && !userId.isBlank()) { sb.append(" AND user_id=?"); args.add(userId); }
        if (projectId != null && !projectId.isBlank()) { sb.append(" AND project_id=?"); args.add(projectId); }
        if (seen != null) { sb.append(" AND seen=?"); args.add(seen ? 1 : 0); }
        sb.append(" ORDER BY fire_at DESC LIMIT ? OFFSET ?");
        args.add(limit); args.add(offset);

        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement ps = conn.prepareStatement(sb.toString())) {
            int i = 1;
            for (Object a : args) ps.setObject(i++, a);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> map = new LinkedHashMap<>();
                    map.put("id", rs.getLong("id"));
                    map.put("userId", rs.getString("user_id"));
                    map.put("projectId", rs.getString("project_id"));
                    map.put("title", rs.getString("title"));
                    map.put("message", rs.getString("message"));
                    map.put("fireAt", rs.getLong("fire_at"));
                    map.put("seen", rs.getInt("seen") == 1);
                    items.add(map);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("listNotifications failed: " + e.getMessage(), e);
        }
        return items;
    }

    public int deleteNotification(long id) {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement ps = conn.prepareStatement("DELETE FROM notifications WHERE id=?")) {
            ps.setLong(1, id);
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("deleteNotification failed: " + e.getMessage(), e);
        }
    }
}
