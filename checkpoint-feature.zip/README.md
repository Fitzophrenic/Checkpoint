
# Checkpoint Apps (Backend + Desktop)

This bundle includes:
- `checkpoint-backend`: Spring Boot + SQLite notification API
- `checkpoint-desktop`: JavaFX desktop client that polls `/api/notifications/due` and shows popups

## Quickstart

### 1) Backend
```
cd checkpoint-backend
mvn spring-boot:run
```
The backend will start at http://localhost:8080.

Create a test notification (fires in ~10s):
```
curl -X POST http://localhost:8080/api/notifications/create   -H "Content-Type: application/json"   -d '{ "userId":"user123", "projectId":"projA", "title":"Playtest", "message":"Starts soon", "fireAt": '$(($(date +%s%3N)+10000))' }'
```

### 2) Desktop
Open a new terminal:
```
cd checkpoint-desktop
mvn -q -DskipTests javafx:run
```
You should see a popup near the bottom-right of the window when the notification becomes due.
